﻿namespace MyNamespace.Common.Modules
{
    public interface IService
    {
        
    }
}