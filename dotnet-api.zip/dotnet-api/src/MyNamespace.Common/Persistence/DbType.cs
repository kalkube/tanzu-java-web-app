﻿namespace MyNamespace.Common.Persistence
{
    public enum DbType
    {
        PostgreSQL,
        

        
        SQLite
    }
}