﻿namespace MyNamespace.Common.Security
{
    public static class KnownScope
    {
        public const string Read = "read";
        public const string Write = "write";
    }
}