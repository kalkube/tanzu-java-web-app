﻿namespace MyNamespace.dotnet-api.Modules.AirportModule.Api
{
    public class Airport
    {
        public string? Id { get; set; } 
        public string? Name { get; set; }
    }
}