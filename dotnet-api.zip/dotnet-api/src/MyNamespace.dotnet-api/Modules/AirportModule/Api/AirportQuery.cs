﻿namespace MyNamespace.dotnet-api.Modules.AirportModule.Api
{
    public partial class AirportQuery
    {
        public string? AirportId { get; set; }
    }
}