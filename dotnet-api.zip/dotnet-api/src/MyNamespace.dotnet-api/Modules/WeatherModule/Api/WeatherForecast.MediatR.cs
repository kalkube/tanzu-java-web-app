﻿using MediatR;

namespace MyNamespace.dotnet-api.Modules.WeatherModule.Api
{
    partial class WeatherForecast : IRequest<WeatherForecast>
    {
        
    }
}