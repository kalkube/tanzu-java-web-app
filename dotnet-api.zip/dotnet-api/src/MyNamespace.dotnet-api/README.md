﻿## Details
- IIS profile removed
## Tools
```
dotnet tool restore
```